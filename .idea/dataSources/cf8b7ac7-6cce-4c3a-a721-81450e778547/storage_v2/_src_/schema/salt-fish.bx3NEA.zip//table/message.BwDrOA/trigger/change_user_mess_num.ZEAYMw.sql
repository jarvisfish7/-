create definer = root@localhost trigger change_user_mess_num
    after insert
    on message
    for each row
    update user set mess_num=mess_num+1 where id=new.mess_to_id;

